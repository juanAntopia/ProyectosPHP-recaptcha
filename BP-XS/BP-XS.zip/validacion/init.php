<?php

use ReCaptcha\ReCaptcha;

require_once '../vendor/autoload.php';

$recaptcha = new ReCaptcha('6LcYHM8UAAAAAFBgtx1BEi0rR-V6McNyG4RXDSQN');